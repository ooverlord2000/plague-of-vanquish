
extends CharacterBody2D
@export var speed: float = 120.0
@export var chase_speed: float = 180.0
var player: Node2D

func _ready():
    player = get_tree().current_scene.get_node_or_null("Player")
    $CollisionShape2D.shape = CircleShape2D.new()
    $CollisionShape2D.shape.radius = 12

func _physics_process(delta):
    if !player: return
    var dir = (player.global_position - global_position)
    var dist = dir.length()
    var target_speed = speed if dist > 100 else chase_speed
    velocity = dir.normalized() * target_speed
    move_and_slide()
    if global_position.distance_to(player.global_position) < 20:
        attack()

func attack():
    # slow player
    if player.has_method("apply_slow"):
        player.apply_slow()
    queue_free()
