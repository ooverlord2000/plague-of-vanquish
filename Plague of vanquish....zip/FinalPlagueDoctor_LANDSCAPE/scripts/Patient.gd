
extends Node2D
enum State {SICK, DEAD, ROTTING, SPAWNED}
var state = State.SICK
var sick_time = 20.0
var dead_time = 15.0

func _process(delta):
    if state == State.SICK:
        sick_time -= delta
        $ProgressBar.value = sick_time
        if sick_time <= 0:
            die()
    elif state == State.DEAD:
        dead_time -= delta
        if dead_time <= 0:
            spawn_plague()

func die():
    state = State.DEAD
    $Sprite.modulate = Color(0.5,0.5,0.5)
    $ProgressBar.modulate = Color.RED

func spawn_plague():
    state = State.SPAWNED
    var enemy_scene = preload("res://scenes/Blightborn.tscn")
    var enemy = enemy_scene.instantiate()
    enemy.global_position = global_position
    get_tree().current_scene.add_child(enemy)
    queue_free()

func cure():
    if state == State.SICK:
        queue_free()
        get_tree().current_scene.add_child(preload("res://scenes/Bed.tscn").instantiate())
