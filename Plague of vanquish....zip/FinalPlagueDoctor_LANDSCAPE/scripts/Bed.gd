
extends StaticBody2D
@export var has_patient: bool = true
func _ready():
    if has_patient:
        var p = preload("res://scenes/Patient.tscn").instantiate()
        $PatientSpawn.add_child(p)
