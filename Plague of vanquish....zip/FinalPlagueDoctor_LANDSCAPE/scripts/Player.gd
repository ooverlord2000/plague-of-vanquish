
extends CharacterBody2D

@export var speed: float = 180.0
var joystick_vector: Vector2 = Vector2.ZERO

func _physics_process(delta):
    var input = Vector2.ZERO
    if joystick_vector.length() > 0.1:
        input = joystick_vector
    else:
        input = Vector2(
            Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
            Input.get_action_strength("move_down") - Input.get_action_strength("move_up")
        )
    input = input.normalized()
    velocity = input * speed
    move_and_slide()
    if input != Vector2.ZERO:
        $Sprite.rotation = input.angle() + PI/2

func set_joystick_input(vec: Vector2):
    joystick_vector = vec
