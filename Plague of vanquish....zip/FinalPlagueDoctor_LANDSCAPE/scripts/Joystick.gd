
extends Control
signal joystick_changed(vec: Vector2)

@onready var bg = $Background
@onready var knob = $Background/Knob
var max_radius: float = 60.0
var dragging = false
var touch_index = -1

func _ready():
    max_radius = bg.size.x / 2

func _gui_input(event):
    if event is InputEventScreenTouch or event is InputEventScreenDrag:
        var pos = event.position
        var center = bg.position + bg.size/2
        if event is InputEventScreenTouch and event.pressed:
            if (pos - center).length() < max_radius * 1.5:
                dragging = true
                touch_index = event.index
        if dragging and event.index == touch_index:
            var dir = pos - center
            var dist = min(dir.length(), max_radius)
            knob.position = center + dir.normalized() * dist - knob.size/2
            var vec = dir.normalized() * (dist / max_radius)
            joystick_changed.emit(vec)
            get_parent().get_parent().get_node("Player").set_joystick_input(vec)
            if event is InputEventScreenTouch and !event.pressed:
                dragging = false
                knob.position = center - knob.size/2
                joystick_changed.emit(Vector2.ZERO)
                get_parent().get_parent().get_node("Player").set_joystick_input(Vector2.ZERO)

func _on_bg_gui_input(event):
    _gui_input(event)
